# vl

![Made in India](https://img.shields.io/badge/MADE%20IN%20-INDIA-blue?style=for-the-badge&logo=appveyor)
![Python](https://img.shields.io/badge/PYTHON%20-TOOL-blue?style=for-the-badge&logo=appveyor)
![prince](https://img.shields.io/badge/PRINCE%20-KUMAR-lightgreen?style=for-the-badge&logo=appveyor)
![GitHub followers](https://img.shields.io/github/followers/princekrvert?color=%23ffbb00&style=for-the-badge)
![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/princekrvert/Asura?color=%2300bbff&style=for-the-badge)
---

![20210115_105855](https://user-images.githubusercontent.com/56459297/104703543-7572a000-573d-11eb-8d9c-771a4bc61696.png)
---
## Termux installation
```

1. git clone https://github.com/pqpvirus12/Crackinsta.git
2. cd Crackinsta
3. chmod +x *
4. ./install.sh 
or ./vl.py


```
---
## Termux look---

![20210115_155339](https://user-images.githubusercontent.com/56459297/104713500-f899f300-5749-11eb-93cc-7e8c0820f78d.jpg)
